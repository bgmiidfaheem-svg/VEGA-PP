// catalog.ts - Vega provider (Vegamovies)
import { Catalog } from '../types';

export const catalog: Catalog[] = [
  { title: "Latest", filter: "/" },
  { title: "Movies", filter: "/category/movies" },
  { title: "TV Shows", filter: "/category/tv-shows" },
  { title: "Bollywood", filter: "/category/bollywood" },
];
