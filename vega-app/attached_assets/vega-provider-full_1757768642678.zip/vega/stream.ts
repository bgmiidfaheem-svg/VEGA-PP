// stream.ts - resolve streams for a selected direct link (returns Stream[])
import { Stream, ProviderContext } from '../types';

export const getStream = async function ({
  link,
  type,
  signal,
  providerContext,
}: {
  link: string;
  type: string;
  signal: AbortSignal;
  providerContext: ProviderContext;
}): Promise<Stream[]> {
  const { axios, commonHeaders } = providerContext;
  try {
    const r = await axios.head(link, { headers: commonHeaders, signal, maxRedirects: 5 });
    const ct = (r.headers && r.headers['content-type']) ? r.headers['content-type'] : '';
    if (/m3u8|application\/vnd\.apple\.mpegurl/i.test(ct) || /\.m3u8(\?|$)/i.test(link)) {
      return [{ server: 'vega', link, type: 'm3u8', quality: '720' }];
    }
    if (/video|octet-stream/i.test(ct) || /\.(mp4|mkv|webm)(\?|$)/i.test(link)) {
      return [{ server: 'vega', link, type: 'direct', quality: '720' }];
    }
  } catch (e) {
    // head may fail — fall back to embed
  }
  return [{ server: 'vega', link, type: 'embed', quality: '720' }];
};
