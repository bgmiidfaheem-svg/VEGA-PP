// types.ts - small local types that mirror project's types (for provider standalone)
export interface Post { title: string; link: string; image?: string; provider?: string; }
export interface Info { title: string; image: string; synopsis: string; imdbId: string; type: string; linkList: any[]; }
export interface Stream { server: string; link: string; type: string; quality?: string; headers?: any; }
export interface EpisodeLink { title: string; link: string; }
export type ProviderContext = any;
