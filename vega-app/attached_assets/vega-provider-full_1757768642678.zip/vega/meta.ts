// meta.ts - returns Info (with linkList)
import { Info, ProviderContext } from '../types';

export const getMeta = async function ({
  link,
  providerContext,
}: {
  link: string;
  providerContext: ProviderContext;
}): Promise<Info> {
  const { axios, cheerio, commonHeaders } = providerContext;
  const res = await axios.get(link, { headers: commonHeaders });
  const $ = cheerio.load(res.data);

  const title = $('h1.entry-title, h1.post-title').first().text().trim() || $('title').text().trim() || '';
  const poster = $('.entry-content img, .post-thumbnail img, .featured img').first();
  const image = poster.attr('data-src') || poster.attr('src') || '';
  const synopsis = $('.entry-content p').first().text().trim() || $('.summary, .post-excerpt').first().text().trim() || '';

  // collect links inside post content
  const scope = $('.entry-content, .post-content, .wp-block-group, .content').first();
  const collected: {title:string, link:string}[] = [];
  scope.find('a[href]').each((_, a) => {
    const $a = $(a);
    const href = $a.attr('href');
    const txt = $a.text().trim() || href;
    if (!href) return;
    const full = new URL(href, link).toString();
    if (/(category|tag|author|#|\/page\/\d+)/i.test(full)) return;
    collected.push({ title: txt, link: full });
  });

  // dedupe
  const seen = new Set();
  const uniq: {title:string, link:string}[] = [];
  for (const l of collected) {
    const k = l.link.split('#')[0];
    if (!seen.has(k)) { seen.add(k); uniq.push(l); }
  }

  // group into linkList entries by hostname
  const groups: Record<string, any[]> = {};
  for (const l of uniq) {
    try {
      const host = new URL(l.link).hostname.replace('www.','');
      groups[host] = groups[host] || [];
      groups[host].push({ title: l.title || l.link, link: l.link, type: 'movie' });
    } catch (e) {
      // ignore malformed
    }
  }
  const linkList = Object.keys(groups).map(h => ({ title: h, episodesLink: '', directLinks: groups[h], quality: '' }));

  const info: Info = {
    title,
    image,
    synopsis,
    imdbId: '',
    type: 'movie',
    linkList
  };
  return info;
};
