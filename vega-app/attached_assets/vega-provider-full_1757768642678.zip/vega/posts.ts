// posts.ts - lists & search (returns Post[] with 'link' field)
import { Post, ProviderContext } from '../types';

export const getPosts = async function ({
  filter,
  page,
  providerValue,
  signal,
  providerContext,
}: {
  filter: string;
  page: number;
  providerValue: string;
  signal: AbortSignal;
  providerContext: ProviderContext;
}): Promise<Post[]> {
  const { axios, cheerio, getBaseUrl, commonHeaders } = providerContext;
  const BASE = getBaseUrl(providerValue) || providerContext.baseUrl || '';
  const path = filter || '/';
  const url = page > 1 ? `${BASE}${path.replace(/\/$/,'')}/page/${page}/` : `${BASE}${path}`;
  const res = await axios.get(url, { headers: commonHeaders, signal });
  const $ = cheerio.load(res.data);
  const items: Post[] = [];
  $('article, .post, .grid-item, .blog-post').each((_, el) => {
    const $el = $(el);
    const a = $el.find('h2 a, h3 a, .post-title a, .entry-title a, a.post-title').first();
    const title = a.text().trim();
    const href = a.attr('href') ? new URL(a.attr('href'), BASE).toString() : null;
    const img = $el.find('img').first().attr('data-src') || $el.find('img').first().attr('src') || '';
    if (href && title) {
      items.push({
        title,
        link: href,
        image: img ? new URL(img, BASE).toString() : '',
      });
    }
  });
  return items;
};

export const getSearchPosts = async function ({
  searchQuery,
  page,
  providerValue,
  signal,
  providerContext,
}: {
  searchQuery: string;
  page: number;
  providerValue: string;
  signal: AbortSignal;
  providerContext: ProviderContext;
}): Promise<Post[]> {
  const { axios, cheerio, getBaseUrl, commonHeaders } = providerContext;
  const BASE = getBaseUrl(providerValue) || providerContext.baseUrl || '';
  const url = `${BASE}/?s=${encodeURIComponent(searchQuery)}${page>1?`&paged=${page}`:''}`;
  const res = await axios.get(url, { headers: commonHeaders, signal });
  const $ = cheerio.load(res.data);
  const items: Post[] = [];
  $('article, .post, .grid-item, .search-result, .result').each((_, el) => {
    const $el = $(el);
    const a = $el.find('h2 a, h3 a, a').first();
    const title = a.text().trim();
    const href = a.attr('href') ? new URL(a.attr('href'), BASE).toString() : null;
    const img = $el.find('img').first().attr('data-src') || $el.find('img').first().attr('src') || '';
    if (href && title) {
      items.push({ title, link: href, image: img ? new URL(img, BASE).toString() : '' });
    }
  });
  return items;
};
