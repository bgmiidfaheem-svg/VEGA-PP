// episodes.ts - optional, fetch episodes for a season/group link
import { EpisodeLink, ProviderContext } from '../types';

export const getEpisodes = async function ({
  url,
  providerContext,
}: {
  url: string;
  providerContext: ProviderContext;
}): Promise<EpisodeLink[]> {
  const { axios, cheerio, commonHeaders } = providerContext;
  const res = await axios.get(url, { headers: commonHeaders });
  const $ = cheerio.load(res.data);
  const eps: EpisodeLink[] = [];
  $('a[href]').each((_, a) => {
    const $a = $(a);
    const href = $a.attr('href');
    const txt = $a.text().trim();
    if (!href) continue;
    if (/episode|ep\s?\d+/i.test(txt) || /ep-?\d+/i.test(href)) {
      eps.push({ title: txt || href, link: new URL(href, url).toString() });
    }
  });
  return eps;
};
